import { Session, ISession } from '../models/Session';
import { Person, IPerson } from '../models/Person';
import { createHttpClient, withTimeout } from '../utils/http';
import { config } from '../config/env';
import { logger } from '../utils/logger';
import { Types } from 'mongoose';
import { searchAndExtract } from './search'; // NEW
import { getCache } from './cache';

interface QuestionOption {
  id: string;
  label: string;
  value: string;
}

interface Question {
  questionId: 'q1' | 'q2' | 'q3' | 'q4' | 'done';
  title: string;
  type: 'single_select';
  options: QuestionOption[];
  hasNoneOfThese: boolean;
  selectedOptionId: string | null;
  context: { sessionId: string };
  nextOnSelect: 'q2' | 'q3' | 'q4' | 'done';
}

interface FinalResults {
  questionId: 'done';
  results: any[];
  cacheUsed: boolean;
}

const MAX_OPTIONS = 15;

// Add small helpers for case-insensitive matching
const norm = (s: string) => (s || '').trim().toLowerCase();
const hasProfessionCI = (c: IPerson, selected: string) =>
  (c.professions || []).some(p => norm(p) === norm(selected));
const includesCI = (arr: string[] = [], v?: string | null) => {
  if (!v) return false;
  const nv = norm(v);
  return arr.some(x => norm(x) === nv);
};

// NEW: robust, fuzzy location match (case/diacritics-insensitive, token-subset)
const stripDiacritics = (s: string) =>
  (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
const canonLoc = (s: string) =>
  stripDiacritics(s)
    .toLowerCase()
    .trim()
    .replace(/-/g, ' ')
    .replace(/\s*,\s*/g, ', ')
    .replace(/\s+/g, ' ');
const LOC_STOP = new Set(['city', 'province', 'state', 'governorate', 'region', 'area', 'district']);
const locTokens = (s: string) =>
  canonLoc(s)
    .split(/[, ]+/)
    .filter(w => w && !LOC_STOP.has(w) && w.length > 1);

function isLocationMatch(a?: string | null, b?: string | null): boolean {
  const ca = canonLoc(a || '');
  const cb = canonLoc(b || '');
  if (!ca || !cb) return false;
  if (ca === cb) return true;
  if (cb.includes(ca) || ca.includes(cb)) return true;
  const ta = locTokens(a || '');
  const tb = locTokens(b || '');
  if (!ta.length || !tb.length) return false;
  // selected tokens subset of candidate tokens
  return ta.every(t => tb.includes(t)) || tb.every(t => ta.includes(t));
}

const includesLocation = (arr: string[] = [], v?: string | null) => {
  if (!v) return false;
  return arr.some(x => isLocationMatch(x, v));
};

// Resolve "selected" that may be an option id (e.g., loc_1) to its label/value.
// Falls back to the raw "selected" if it doesn't match an id.
async function resolveSelectedValueForAnswer(
  session: ISession,
  candidates: IPerson[],
  qid: string,
  selected: string,
): Promise<string> {
  const sel = (selected || '').trim();
  if (!sel || sel === 'none') return 'none';

  const resolveFrom = async (builder: () => Promise<Question>, prefix: string) => {
    const q = await builder();
    const hit = q.options.find(o => o.id === sel);
    return hit ? hit.value : sel;
  };

  switch (qid) {
    case 'q1':
      return resolveFrom(() => buildProfessionQuestion(session, candidates), 'prof_');
    case 'q2':
      return resolveFrom(() => buildLocationQuestion(session, candidates), 'loc_');
    case 'q3':
      return resolveFrom(() => buildEmployerQuestion(session, candidates), 'emp_');
    case 'q4':
      return resolveFrom(() => buildEducationQuestion(session, candidates), 'edu_');
    default:
      return sel;
  }
}

// Build query variants to expand search when "none" is selected
function buildQueryVariantsForExpansion(session: ISession, answeredQ: 'q1' | 'q2' | 'q3' | 'q4'): string[] {
  const base = (session.query || '').trim();
  const prof = session.answers.profession && session.answers.profession !== 'none' ? session.answers.profession : '';
  const loc = session.answers.location && session.answers.location !== 'none' ? session.answers.location : '';
  const emp = session.answers.employer && session.answers.employer !== 'none' ? session.answers.employer : '';
  const edu = session.answers.education && session.answers.education !== 'none' ? session.answers.education : '';

  const uniq = (arr: string[]) => Array.from(new Set(arr.filter(Boolean).map(s => s.trim())));

  switch (answeredQ) {
    case 'q1':
      return uniq([
        `${base} site:linkedin.com/in`,
        `${base} LinkedIn profile`,
        `${base} profile site:linkedin.com`,
        `${base} people LinkedIn`,
      ]);
    case 'q2':
      // Include selected location to better intersect with profession
      if (loc) {
        return uniq([
          `${base} ${prof} ${loc} site:linkedin.com/in`,
          `${base} ${prof} ${loc} LinkedIn`,
          `"${base}" ${prof} ${loc} site:linkedin.com`,
          `${base} ${prof} ${loc} people LinkedIn`,
          // fallback without loc
          `${base} ${prof} site:linkedin.com/in`,
        ]);
      }
      // No location yet, keep original broad variants
      return uniq([
        `${base} ${prof} site:linkedin.com/in`,
        `${base} ${prof} LinkedIn`,
        `${prof} "${base}" site:linkedin.com`,
        `${base} ${prof} people`,
      ]);
    case 'q3':
      return uniq([
        `${base} ${prof} ${loc} site:linkedin.com/in`,
        `${base} ${prof} ${loc} LinkedIn`,
        `"${base}" ${prof} ${loc} site:linkedin.com`,
        `${base} ${loc} people LinkedIn`,
      ]);
    case 'q4':
      return uniq([
        `${base} ${emp} site:linkedin.com/in`,
        `${base} ${emp} LinkedIn`,
        `${base} ${prof} ${emp} site:linkedin.com`,
        `${base} ${edu} alumni LinkedIn`,
      ]);
    default:
      return uniq([`${base} site:linkedin.com/in`, `${base} LinkedIn`]);
  }
}

// Expand session candidates using AI search if "none" was selected
async function expandCandidatesAfterNone(
  session: ISession,
  candidates: IPerson[],
  answeredQ: 'q1' | 'q2' | 'q3' | 'q4',
): Promise<IPerson[]> {
  try {
    const queries = buildQueryVariantsForExpansion(session, answeredQ);
    if (!queries.length) return [];

    const existingIds = new Set<string>(candidates.map(c => String(c._id)));
    const newlyFound: IPerson[] = [];

    for (const q of queries) {
      // Use existing AI + providers pipeline
      const persons = await searchAndExtract(q);
      for (const p of persons) {
        const pid = String(p._id);
        if (!existingIds.has(pid)) {
          existingIds.add(pid);
          newlyFound.push(p);
        }
      }
      // Stop early if we found a decent batch
      if (newlyFound.length >= 10) break;
    }

    if (newlyFound.length) {
      // Persist to session
      const newIds = newlyFound.map(p => new Types.ObjectId(p._id));
      session.candidates.push(...newIds);
      await session.save();
      logger.info('Expanded session candidates after "none"', {
        sessionId: session.id,
        answeredQ,
        added: newlyFound.length,
      });
    }

    return newlyFound;
  } catch (err: any) {
    logger.warn('Failed to expand candidates after "none"', { message: err?.message });
    return [];
  }
}

// NEW: compute candidates matching current answers (shared logic with final result)
function filterCandidatesForSession(session: ISession, candidates: IPerson[]): IPerson[] {
  let final = candidates;

  if (session.answers.profession && session.answers.profession !== 'none') {
    final = final.filter(c => (c.professions || []).some(p => norm(p) === norm(session.answers.profession!)));
  }
  if (session.answers.location && session.answers.location !== 'none') {
    final = final.filter(c => includesLocation(c.locations, session.answers.location!));
  }
  if (session.answers.employer && session.answers.employer !== 'none') {
    final = final.filter(c => includesCI(c.employers, session.answers.employer!));
  }
  if (session.answers.education && session.answers.education !== 'none') {
    final = final.filter(c => includesCI(c.education, session.answers.education!));
  }
  return final;
}

// NEW: expand when a non-"none" answer yields no matches
async function expandCandidatesAfterSelection(
  session: ISession,
  candidates: IPerson[],
  answeredQ: 'q1' | 'q2' | 'q3' | 'q4',
): Promise<IPerson[]> {
  try {
    const queries = buildQueryVariantsForExpansion(session, answeredQ);
    if (!queries.length) return [];

    const existingIds = new Set<string>(candidates.map(c => String(c._id)));
    const newlyFound: IPerson[] = [];

    for (const q of queries) {
      const persons = await searchAndExtract(q);
      for (const p of persons) {
        const pid = String(p._id);
        if (!existingIds.has(pid)) {
          existingIds.add(pid);
          newlyFound.push(p);
        }
      }
      if (newlyFound.length >= 10) break;
    }

    if (newlyFound.length) {
      const newIds = newlyFound.map(p => new Types.ObjectId(p._id));
      session.candidates.push(...newIds);
      await session.save();
      logger.info('Expanded session candidates after selection', {
        sessionId: session.id,
        answeredQ,
        added: newlyFound.length,
      });
    }

    return newlyFound;
  } catch (err: any) {
    logger.warn('Failed to expand candidates after selection', { message: err?.message });
    return [];
  }
}

export async function buildNextQuestion(
  sessionId: string,
  answer?: { questionId: string; selected: string },
): Promise<Question | FinalResults> {
  const session = await Session.findById(sessionId).populate('candidates');
  if (!session) throw new Error('Session not found');

  const candidates = session.candidates as unknown as IPerson[];

  logger.info('buildNextQuestion enter', {
    sessionId,
    flowState: session.flowState,
    candidatesCount: candidates.length,
    hasAnswer: !!answer,
  });

  // Update answers if provided (accept both option ids and raw labels)
  if (answer) {
    const resolved = await resolveSelectedValueForAnswer(session, candidates, answer.questionId, answer.selected);
    logger.info('Answer resolved', { sessionId, qid: answer.questionId, selected: answer.selected, resolved });

    switch (answer.questionId) {
      case 'q1':
        session.answers.profession = resolved;
        session.flowState = 'q2';
        break;
      case 'q2':
        session.answers.location = resolved;
        {
          const prof = session.answers.profession ?? 'none';
          const loc = session.answers.location ?? 'none';
          const nonNone = (prof === 'none' ? 0 : 1) + (loc === 'none' ? 0 : 1);
          session.flowState = nonNone === 2 ? 'done' : 'q3';
        }
        break;
      case 'q3':
        session.answers.employer = resolved;
        {
          const bothFirstTwoNone =
            (session.answers.profession ?? 'none') === 'none' &&
            (session.answers.location ?? 'none') === 'none';
          session.flowState = bothFirstTwoNone ? 'q4' : 'done';
        }
        break;
      case 'q4':
        session.answers.education = resolved;
        session.flowState = 'done';
        break;
    }

    // If user selected "none", try to expand candidates before proceeding
    if (resolved === 'none') {
      const answeredQ = answer.questionId as 'q1' | 'q2' | 'q3' | 'q4';
      const newOnes = await expandCandidatesAfterNone(session, candidates, answeredQ);
      if (newOnes.length) {
        candidates.push(...newOnes);
        logger.info('Expanded after "none" selection', {
          sessionId: session.id,
          answeredQ,
          added: newOnes.length,
          totalCandidates: candidates.length,
        });
      }
    } else {
      // For non-"none" selection, if no current matches, search more
      const matchesNow = filterCandidatesForSession(session, candidates).length;
      if (matchesNow === 0) {
        const answeredQ = answer.questionId as 'q1' | 'q2' | 'q3' | 'q4';
        // Previously we suppressed expansion after q2 when both selected; remove suppression to prevent empty finals
        const newOnes = await expandCandidatesAfterSelection(session, candidates, answeredQ);
        if (newOnes.length) {
          candidates.push(...newOnes);
          logger.info('Expanded after selection due to zero matches', {
            sessionId: session.id,
            answeredQ,
            added: newOnes.length,
            totalCandidates: candidates.length,
          });
        } else {
          logger.info('No expansion results after selection (zero matches persisted)', {
            sessionId: session.id,
            answeredQ,
          });
        }
      }
    }

    await session.save();
  }

  switch (session.flowState) {
    case 'q1': {
      const q = await buildProfessionQuestion(session, candidates);
      logger.info('Built q1', { sessionId: session.id, optionCount: q.options.length });
      return q;
    }
    case 'q2': {
      const q = await buildLocationQuestion(session, candidates);
      logger.info('Built q2', { sessionId: session.id, optionCount: q.options.length });
      return q;
    }
    case 'q3': {
      const q = await buildEmployerQuestion(session, candidates);
      logger.info('Built q3', { sessionId: session.id, optionCount: q.options.length });
      return q;
    }
    case 'q4': {
      const q = await buildEducationQuestion(session, candidates);
      logger.info('Built q4', { sessionId: session.id, optionCount: q.options.length });
      return q;
    }
    case 'done': {
      const final = await buildFinalResults(session, candidates); // await async
      logger.info('Built final results', {
        sessionId: session.id,
        resultsCount: final.results.length,
        cacheUsed: final.cacheUsed,
      });
      return final;
    }
    default:
      throw new Error('Invalid flow state');
  }
}

async function buildProfessionQuestion(
  session: ISession,
  candidates: IPerson[],

): Promise<Question> {
  // Only surface a single primary profession per candidate to avoid duplicate labels
  const professionMap = new Map<string, string>();
  for (const c of candidates) {
    const primary = (c.professions?.[0] || '').trim();
    if (!primary) continue;
    const key = primary.toLowerCase();
    if (!professionMap.has(key)) {
      professionMap.set(key, primary);
    }
  }

  let options: QuestionOption[] = Array.from(professionMap.values())
    .sort((a, b) => a.localeCompare(b))
    .map((p, i) => ({
      id: `prof_${i}`,
      label: p,
      value: p,
    }));

  options = options.slice(0, MAX_OPTIONS);

  options.push({
    id: 'none',
    label: 'None of these',
    value: 'none',
  });

  return {
    questionId: 'q1',
    title: 'What is their profession?',
    type: 'single_select',
    options,
    hasNoneOfThese: true,
    selectedOptionId: null,
    context: { sessionId: session.id },
    nextOnSelect: 'q2',
  };
}

async function buildLocationQuestion(
  session: ISession,
  candidates: IPerson[],
): Promise<Question> {
  const locations = new Set<string>();

  // Keep options from filtered (if profession selected)
  let filtered = candidates;
  if (session.answers.profession && session.answers.profession !== 'none') {
    filtered = candidates.filter(c => hasProfessionCI(c, session.answers.profession!));
  }

  const addLocationsFrom = (list: IPerson[]) => {
    list.forEach(c =>
      (c.locations || []).forEach(l => {
        const t = (l || '').trim();
        if (t) locations.add(t);
      }),
    );
  };

  // Prefer filtered; if it yields no locations, fall back to all candidates.
  if (filtered.length) {
    addLocationsFrom(filtered);
    if (locations.size === 0) {
      addLocationsFrom(candidates);
    }
  } else {
    addLocationsFrom(candidates);
  }

  let options: QuestionOption[] = Array.from(locations)
    .sort((a, b) => a.localeCompare(b))
    .map((l, i) => ({
      id: `loc_${i}`,
      label: l,
      value: l,
    }));

  options = options.slice(0, MAX_OPTIONS);

  options.push({
    id: 'none',
    label: 'None of these',
    value: 'none',
  });

  return {
    questionId: 'q2',
    title: 'Where are they located?',
    type: 'single_select',
    options,
    hasNoneOfThese: true,
    selectedOptionId: null,
    context: { sessionId: session.id },
    nextOnSelect: 'q3',
  };
}

async function buildEmployerQuestion(
  session: ISession,
  candidates: IPerson[],
): Promise<Question> {
  const employers = new Set<string>();

  let filtered = candidates;
  if (session.answers.location && session.answers.location !== 'none') {
    filtered = candidates.filter(c => includesLocation(c.locations, session.answers.location!));
  }

  const addEmployersFrom = (list: IPerson[]) => {
    list.forEach(c =>
      (c.employers || []).forEach(e => {
        const t = (e || '').trim();
        if (t) employers.add(t);
      }),
    );
  };

  // Use filtered primarily; fall back if empty to avoid dead-end UX
  if (filtered.length) addEmployersFrom(filtered);
  else addEmployersFrom(candidates);

  let options: QuestionOption[] = Array.from(employers)
    .sort((a, b) => a.localeCompare(b))
    .map((e, i) => ({
      id: `emp_${i}`,
      label: e,
      value: e,
    }));

  options = options.slice(0, MAX_OPTIONS);

  options.push({
    id: 'none',
    label: 'None of these',
    value: 'none',
  });

  return {
    questionId: 'q3',
    title: 'Where do they work?',
    type: 'single_select',
    options,
    hasNoneOfThese: true,
    selectedOptionId: null,
    context: { sessionId: session.id },
    nextOnSelect: 'q4',
  };
}

async function buildEducationQuestion(
  session: ISession,
  candidates: IPerson[],
): Promise<Question> {
  const education = new Set<string>();

  let filtered = candidates;
  if (session.answers.employer && session.answers.employer !== 'none') {
    filtered = candidates.filter(c => includesCI(c.employers, session.answers.employer!));
  }

  const addEducationFrom = (list: IPerson[]) => {
    list.forEach(c =>
      (c.education || []).forEach(e => {
        const t = (e || '').trim();
        if (t) education.add(t);
      }),
    );
  };

  // Use filtered primarily; fall back if empty
  if (filtered.length) addEducationFrom(filtered);
  else addEducationFrom(candidates);

  let options: QuestionOption[] = Array.from(education)
    .sort((a, b) => a.localeCompare(b))
    .map((e, i) => ({
      id: `edu_${i}`,
      label: e,
      value: e,
    }));

  options = options.slice(0, MAX_OPTIONS);

  options.push({
    id: 'none',
    label: 'None of these',
    value: 'none',
  });

  return {
    questionId: 'q4',
    title: 'Where did they study?',
    type: 'single_select',
    options,
    hasNoneOfThese: true,
    selectedOptionId: null,
    context: { sessionId: session.id },
    nextOnSelect: 'done',
  };
}

// Helper to apply all session filters to candidates and log counts
function applyAllFilters(session: ISession, candidates: IPerson[]): IPerson[] {
  const before = candidates.length;
  let filtered = candidates;

  if (session.answers.profession && session.answers.profession !== 'none') {
    filtered = filtered.filter(c => hasProfessionCI(c, session.answers.profession!));
  }
  if (session.answers.location && session.answers.location !== 'none') {
    filtered = filtered.filter(c => includesLocation(c.locations, session.answers.location!));
  }
  if (session.answers.employer && session.answers.employer !== 'none') {
    filtered = filtered.filter(c => includesCI(c.employers, session.answers.employer!));
  }
  if (session.answers.education && session.answers.education !== 'none') {
    filtered = filtered.filter(c => includesCI(c.education, session.answers.education!));
  }

  logger.info('Applied filters', {
    sessionId: session.id,
    before,
    after: filtered.length,
    answers: session.answers,
  });

  return filtered;
}

// Last-chance expansion when final results would be empty
async function ensureNonEmptyFinalCandidates(
  session: ISession,
  candidates: IPerson[],
): Promise<{ final: IPerson[]; expanded: boolean }> {
  let current = applyAllFilters(session, candidates);
  if (current.length > 0) return { final: current, expanded: false };

  logger.warn('Final candidates empty; attempting last-chance expansion', {
    sessionId: session.id,
    answers: session.answers,
  });

  const order: Array<'q4' | 'q3' | 'q2' | 'q1'> = ['q4', 'q3', 'q2', 'q1'];
  for (const step of order) {
    const added = await expandCandidatesAfterSelection(session, candidates, step);
    if (added.length) {
      candidates.push(...added);
      current = applyAllFilters(session, candidates);
      logger.info('Last-chance expansion step complete', {
        sessionId: session.id,
        step,
        added: added.length,
        matchedAfter: current.length,
      });
      if (current.length > 0) return { final: current, expanded: true };
    } else {
      logger.info('No additions from last-chance expansion step', { sessionId: session.id, step });
    }
  }

  return { final: current, expanded: false };
}

async function buildFinalResults(session: ISession, candidates: IPerson[]): Promise<FinalResults> {
  // Compute final candidates; if empty, try last-chance expansion
  const { final: initialFiltered } = { final: applyAllFilters(session, candidates) };
  let expandedUsed = false;
  let finalCandidates = initialFiltered;

  if (finalCandidates.length === 0) {
    const ensured = await ensureNonEmptyFinalCandidates(session, candidates);
    finalCandidates = ensured.final;
    expandedUsed = ensured.expanded;
  }

  // Determine cacheUsed: cache hit and no selected answer is "none"
  const cached = getCache<IPerson[]>(session.cacheKey);
  const noNoneSelected =
    ['profession', 'location', 'employer', 'education']
      .every((k) => (session.answers as any)[k] === undefined || (session.answers as any)[k] !== 'none');

  // If we had to expand at final stage, we did not rely purely on cache.
  const cacheUsed = expandedUsed ? false : !!(cached.hit && noNoneSelected);

  const results = finalCandidates.map(c => ({
    personId: c._id.toString(),
    fullName: c.fullName,
    firstName: c.firstName,
    middleName: c.middleName,
    lastName: c.lastName,
    profession: c.professions[0] || null,
    location: c.locations[0] || null,
    employer: c.employers[0] || null,
    education: c.education,
    emails: c.emails,
    phones: c.phones,
    social: c.social,
    age: c.age,
    gender: c.gender,
    relatedPeople: c.relatedPeople,
    confidence: c.confidence,
  }));

  logger.info('buildFinalResults summary', {
    sessionId: session.id,
    resultsCount: results.length,
    expandedUsed,
    cacheHit: cached.hit,
    cacheUsed,
  });

  return {
    questionId: 'done',
    results,
    cacheUsed,
  };
}