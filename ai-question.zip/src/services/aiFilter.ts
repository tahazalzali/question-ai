import { createHttpClient, withTimeout, normalizeEmail, normalizePhone } from '../utils/http';
import { config } from '../config/env';
import { logger } from '../utils/logger';
import { z } from 'zod';

const candidateSchema = z.object({
  fullName: z.string(),
  firstName: z.string().nullable().optional(),
  middleName: z.string().nullable().optional(),
  lastName: z.string().nullable().optional(),
  professions: z.array(z.string()).default([]),
  employers: z.array(z.string()).default([]),
  education: z.array(z.string()).default([]),
  emails: z.array(z.string()).default([]),
  phones: z.array(z.string()).default([]),
  social: z.object({
    instagram: z.string().nullable().optional(),
    facebook: z.string().nullable().optional(),
    twitter: z.string().nullable().optional(),
    linkedin: z.string().nullable().optional(),
    tiktok: z.string().nullable().optional(),
  }).default({}),
  age: z.number().nullable().optional(),
  gender: z.enum(['male', 'female', 'other']).nullable().optional(),
  locations: z.array(z.string()).default([]),
  relatedPeople: z.array(z.object({
    fullName: z.string(),
    relation: z.string().nullable().optional(),
    linkedin: z.string().nullable().optional(),
  })).default([]),
  sources: z.array(z.object({
    provider: z.enum(['perplexity', 'gemini', 'brave']),
    url: z.string().optional(),
    note: z.string().optional(),
  })).default([]),
  confidence: z.number().min(0).max(1).default(0.5),
});

const responseSchema = z.object({
  candidates: z.array(candidateSchema).default([]),
});

function compactResults(rawResults: any[], cap = 12) {
  const trim = (s?: string, n = 300) => (s ? s.slice(0, n) : '');
  return rawResults.slice(0, cap).map(r => ({
    title: trim(r.title || '', 160),
    url: r.url || r.link || '',
    snippet: trim(r.snippet || '', 500),
    provider: r.provider,
  }));
}

function extractJson(text: string): string {
  const t = (text || '').trim();
  const fenced = t.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const body = fenced ? fenced[1] : t;
  const start = body.indexOf('{');
  const end = body.lastIndexOf('}');
  if (start !== -1 && end !== -1 && end > start) {
    return body.slice(start, end + 1);
  }
  return body;
}

function canonicalizeLinkedIn(link?: string | null): string | null {
  if (!link) return null;
  const ln = link.trim();
  if (!ln) return null;
  if (/^https?:\/\//i.test(ln)) return ln;
  const handle = ln.replace(/^@/, '').replace(/^in\//, '');
  return `https://www.linkedin.com/in/${handle}`;
}

function canonicalizeLocation(loc: string): string {
  const s = (loc || '').trim();
  if (!s) return s;

  const lower = s.toLowerCase();

  const us = /^(us|usa|u\.s\.a\.|united states|united states of america)$/i;
  const uk = /^(uk|u\.k\.|united kingdom|england|scotland|wales|northern ireland)$/i;
  const nyc = /^(nyc|new york city)$/i;
  const sfba = /^(bay area|sfo|san francisco bay area)$/i;

  if (us.test(lower)) return 'United States';
  if (uk.test(lower)) return 'United Kingdom';
  if (nyc.test(lower) || lower.includes('new york, ny')) return 'New York, USA';
  if (sfba.test(lower)) return 'San Francisco Bay Area, USA';

  return s.replace(/\s*,\s*/g, ', ').replace(/\s+/g, ' ').trim();
}

export async function filterAndNormalize(rawResults: any[]): Promise<any[]> {
  if (!rawResults?.length) return [];

  const client = createHttpClient(config.perplexity.baseUrl, 65000);

  const systemPrompt = `You are a strict information extractor. Use only provided snippets/URLs. Do not invent data.
Rules:
- Merge records that refer to the same person across sources (match by LinkedIn, email, phone, or strong name+employer).
- Consolidate synonymous professions into a single canonical label per person (e.g., "Software Developer" and "Software Engineer" -> "Software Engineer").
- Put the primary role first in "professions". Keep all arrays unique, de-duplicated, and concise.
- Normalize institutions and locations (e.g., use full university names; map common abbreviations like NYC -> New York, USA; USA/US/United States -> United States; UK/United Kingdom -> United Kingdom; Bay Area -> San Francisco Bay Area, USA).
- Prefer direct, canonical URLs (e.g., https://www.linkedin.com/in/...); avoid redirector/tracking URLs.
- If unknown, output null or omit.
- Never fabricate information.
Output only raw JSON as a single object. No markdown, no code fences, no additional text.`;

  async function requestOnce(compact: any[]) {
    const userPrompt = `From these search results, extract real people and return STRICT JSON per the schema.
Schema:
{
  "candidates": [{
    "fullName": "string",
    "firstName": "string|null",
    "middleName": "string|null",
    "lastName": "string|null",
    "professions": ["string"], // canonical, unique, primary first
    "employers": ["string"],
    "education": ["string"],
    "emails": ["string"],
    "phones": ["string"],
    "social": { "instagram": "string|null", "facebook": "string|null", "twitter": "string|null", "linkedin": "string|null", "tiktok": "string|null" },
    "age": "number|null",
    "gender": "male|female|other|null",
    "locations": ["string"],
    "relatedPeople": [{"fullName":"string","relation":"string|null","linkedin":"string|null"}],
    "sources": [{"provider":"perplexity|gemini|brave","url":"string","note":"string"}],
    "confidence": 0.0-1.0
  }...]
}
Rules:
- Merge duplicates across sources into one candidate.
- Canonicalize professions (avoid near-duplicate titles like "Software Developer" vs "Software Engineer").
- Use direct URLs only; if a LinkedIn handle is present, convert to full LinkedIn profile URL.
Strictly return only the JSON object. No backticks or explanations.
INPUT: ${JSON.stringify(compact)}`;

    return withTimeout(
      client.post(
        '/chat/completions',
        {
          model: 'sonar-pro',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ],
          temperature: 0,
        },
        {
          headers: {
            Authorization: `Bearer ${config.perplexity.apiKey}`,
          },
        },
      ),
      60000, // watchdog 60s
      'AI filtering request timeout',
    );
  }

  const variants = [
    compactResults(rawResults, 12),
    compactResults(rawResults, 8),
    compactResults(rawResults, 5),
  ];

  for (let i = 0; i < variants.length; i++) {
    try {
      const resp = await requestOnce(variants[i]);
      const content = resp.data?.choices?.[0]?.message?.content || '';
      if (!content) return [];

      const cleaned = extractJson(content);
      let parsed: unknown;
      try {
        parsed = JSON.parse(cleaned);
      } catch (e) {
        logger.warn('AI filtering JSON parse failed', { excerpt: cleaned.slice(0, 200) });
        throw e;
      }
      const validated = responseSchema.parse(parsed);

      const uniqCI = (arr: string[]) => {
        const seen = new Set<string>();
        const out: string[] = [];
        for (const v of arr.filter(Boolean)) {
          const key = v.trim().toLowerCase();
          if (!key || seen.has(key)) continue;
          seen.add(key);
          out.push(v.trim());
        }
        return out;
      };

      return validated.candidates.map(c => {
        const linkedin = canonicalizeLinkedIn(c.social?.linkedin || null);
        const sources =
          Array.isArray(c.sources)
            ? Array.from(new Map(
                c.sources.map(s => [`${s.provider}:${s.url || ''}`, s]),
              ).values())
            : [];

        return {
          ...c,
          professions: uniqCI(c.professions),
          employers: uniqCI(c.employers),
          education: uniqCI(c.education),
          emails: uniqCI(c.emails.map(normalizeEmail)),
          phones: uniqCI(c.phones.map(normalizePhone)),
          locations: uniqCI(
            c.locations.map(loc => {
              return canonicalizeLocation(loc);
            }),
          ),
          social: { ...c.social, linkedin },
          sources,
        };
      });
    } catch (error: any) {
      const data = error?.response?.data;
      const isTimeout =
        error?.code === 'ECONNABORTED' ||
        /timeout/i.test(error?.message || '') ||
        /request timeout/i.test(error?.message || '');
      const meta = {
        message: error?.message,
        status: error?.response?.status,
        data,
      };
      if (isTimeout) {
        logger.warn(`AI filtering timed out (attempt ${i + 1}); will try a smaller context`, meta);
      } else {
        logger.error(`AI filtering failed (attempt ${i + 1})`, meta);
      }
       if (i === variants.length - 1) return [];
    }
  }

  return [];
}